
<script type="text/javascript">

$(document).on('shiny:idle', function(event) {
  alert('Finished!');
});

</script>