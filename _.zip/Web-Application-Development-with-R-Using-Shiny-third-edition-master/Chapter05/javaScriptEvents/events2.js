
<script type="text/javascript">

$('#testPlot').on('shiny:recalculated', function(event) {
  alert("Finished");
});

</script>